# gon CLI

A CLI for gon.

## Customizing your CLI

Check out the documentation at https://github.com/infinitered/gluegun/tree/master/docs.

## Publishing to NPM

To package your CLI up for NPM, do this:

### How to use
1. In the root dir, run these following commands: yarn link
2. Then use it anywhere, available commands(in the folder src/commands): 
  - gon component <name>
  - gon utils <name>
  - gon screen <name>


# License

MIT - see LICENSE

